package com.mcaps.mmm.ui.question

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mcaps.mmm.databinding.ActivityQuestionBinding
import com.mcaps.mmm.ui.LoginActivity  // Import the LoginActivity

class QuestionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityQuestionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate the layout using ViewBinding
        binding = ActivityQuestionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Button "Mulai Tes" action
        binding.btnStartTest.setOnClickListener {
            // Replace with RulesFragment
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(android.R.id.content, RulesFragment())  // Replace with the RulesFragment
            transaction.addToBackStack(null)  // To allow back navigation
            transaction.commit()
        }

        // Button "Login" action
        binding.btnLogin.setOnClickListener {
            // Navigate to LoginActivity when "Login" button is clicked
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }
}
