package com.mcaps.mmm

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.mcaps.mmm.databinding.ActivityMainBinding
import com.mcaps.mmm.ui.ViewPagerAdapter
import com.mcaps.mmm.ui.menu.SettingPreferences
import com.mcaps.mmm.ui.menu.dataStore
import com.mcaps.mmm.ui.question.QuestionActivity

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Theme management
        val pref = SettingPreferences.getInstance(application.dataStore)
        val mainViewModel = ViewModelProvider(this, ViewModelFactory(pref)).get(MainViewModel::class.java)

        // Observe the theme settings
        mainViewModel.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            // Set dark or light mode based on user preference
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }

        // Setup ViewPager2
        val viewPager: ViewPager2 = binding.viewPager
        val navView: BottomNavigationView = binding.navView

        // Set adapter for ViewPager2
        val adapter = ViewPagerAdapter(this)
        viewPager.adapter = adapter

        // Sync BottomNavigationView with ViewPager2
        navView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> viewPager.setCurrentItem(0, true)
                R.id.navigation_dashboard -> viewPager.setCurrentItem(1, true)
                R.id.navigation_notifications -> viewPager.setCurrentItem(2, true)
                R.id.navigation_menu -> viewPager.setCurrentItem(3, true)
            }
            true
        }

        // Sync ViewPager2 with BottomNavigationView
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                navView.menu.getItem(position).isChecked = true
            }
        })

        // Handle FloatingActionButton click to navigate to QuestionActivity
        binding.question.setOnClickListener {
            // Start QuestionActivity when FAB is clicked
            val intent = Intent(this, QuestionActivity::class.java)
            startActivity(intent)
        }
    }
}
